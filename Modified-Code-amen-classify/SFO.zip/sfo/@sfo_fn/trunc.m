% Implementation by Andreas Krause (krausea@gmail.com)
% 
% Example: See sfo_fn.m and the tutorial script for more information

function F = trunc(F,c)
F = sfo_fn_trunc(F,c);
